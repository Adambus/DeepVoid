#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Interaction/InteractableInterface.h"
#include "ShipModule_Weapon.generated.h"

class UStaticMeshComponent;
class UInputMappingContext;
class UInputAction;
struct FInputActionValue;

/**
 * Оружие как отдельная "турель"-Pawn, независимая от штурвала. F рядом с ним -
 * отдельная посадка (Possess), не связанная с пилотированием всего корабля.
 * Пока сидите за турелью: A/D (или мышь) крутят ствол в пределах ±45°, ЛКМ стреляет,
 * повторный F/Esc возвращает управление персонажу.
 */
UCLASS()
class DEEPVOID_API AShipModule_Weapon : public APawn, public IInteractableInterface
{
	GENERATED_BODY()

public:
	AShipModule_Weapon();

protected:
	virtual void BeginPlay() override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	// Пустой корень, вокруг которого крутится прицел (Yaw). Раньше был просто локальной
	// переменной в конструкторе - из-за этого BP-редактор показывал его как "чужой"
	// generic-компонент без нормального Details (пустая панель, синий/неактивный вид).
	// Теперь это настоящий UPROPERTY-член класса, как и остальные компоненты ниже.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<USceneComponent> TurretRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<UStaticMeshComponent> Mesh;

	// Без своей камеры Possess() переключает управление, но игрок физически ничего не видит -
	// именно поэтому "F нажата" срабатывало, а визуально ничего не менялось.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<class USpringArmComponent> SpringArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<class UCameraComponent> TurretCamera;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float MaxTraverseDegrees = 45.f;

	// Чувствительность мыши - на сколько градусов крутить ствол за один "пиксель"
	// сырой дельты движения мыши. Подберите под вкус в BP.
	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float MouseSensitivity = 0.3f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float Damage = 25.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float Range = 6000.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float FireRate = 0.3f;

	UPROPERTY(ReplicatedUsing = OnRep_CurrentYawOffset, BlueprintReadOnly, Category = "Weapon")
	float CurrentYawOffset = 0.f;

	// Кого "занял" оператор - чтобы вернуть управление при выходе.
	UPROPERTY(Replicated)
	TObjectPtr<APawn> OperatorOriginalPawn;

	// Явный флаг "занята ли турель прямо сейчас игроком". НЕ полагаемся на встроенное поле
	// Controller у APawn - оно может быть занято автоматическим AI-контроллером движка
	// (AutoPossessAI по умолчанию), из-за чего проверка "Controller == nullptr" ошибочно
	// решала, что турель занята, и молча блокировала взаимодействие.
	UPROPERTY(Replicated)
	bool bIsOccupiedByPlayer = false;

	FTimerHandle FireCooldownHandle;
	bool bCanFire = true;

	// --- Ввод во время управления турелью ---
	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputMappingContext> TurretMappingContext;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> FireAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> ExitTurretAction;

	// Axis2D, замаппленный на "Mouse XY 2D-Axis" в IMC - сырая дельта движения мыши
	// за кадр. Работает даже при захваченном/скрытом курсоре, в отличие от прошлой
	// версии через DeprojectMousePositionToWorld (для неё нужна была видимая мышь и
	// ручное переключение InputMode при входе/выходе из турели - лишняя сложность).
	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> RotateAction;

	UFUNCTION()
	void OnRep_CurrentYawOffset();

	void ResetFireCooldown() { bCanFire = true; }

	void Input_Rotate(const FInputActionValue& Value);
	void Input_Fire(const FInputActionValue& Value);
	void Input_ExitTurret(const FInputActionValue& Value);

	UFUNCTION(Server, Unreliable)
	void ServerRotate(float MouseDeltaX);

	UFUNCTION(Server, Reliable)
	void ServerFire();

	UFUNCTION(Server, Reliable)
	void ServerExitTurret();

public:
	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const override;

	void Fire();

	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void EnterTurret(APawn* CharacterToStore, AController* InstigatingController);

	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void ExitTurret();

	// --- IInteractableInterface ---
	virtual FText GetInteractionPrompt_Implementation() const override;
	virtual bool CanInteract_Implementation(AActor* InteractingActor) const override;
	virtual void OnInteract_Implementation(AActor* InteractingActor) override;
};

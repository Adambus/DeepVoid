#include "Ship/ShipModule_Bridge.h"
#include "Ship/Ship.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Controller.h"

AShipModule_Bridge::AShipModule_Bridge()
{
	bReplicates = true;

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	SetRootComponent(Mesh);
	// Обязательно, иначе персонаж, физически стоящий на мостике, не сможет "ехать" вместе
	// с кораблём как на движущейся платформе (см. тот же фикс у AShip::HullMesh) - движок
	// осознанно игнорирует Static-компоненты как потенциальную опору для персонажа.
	Mesh->SetMobility(EComponentMobility::Movable);
	Mesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
}

FText AShipModule_Bridge::GetInteractionPrompt_Implementation() const
{
	return NSLOCTEXT("DeepVoid", "BridgeEnter", "Занять штурвал");
}

bool AShipModule_Bridge::CanInteract_Implementation(AActor* InteractingActor) const
{
	// Всегда true - реальную проверку (назначен ли корабль) делаем в OnInteract,
	// чтобы при пустом AssignedShip игрок видел понятное сообщение, а не тишину.
	return true;
}

void AShipModule_Bridge::OnInteract_Implementation(AActor* InteractingActor)
{
	if (!AssignedShip)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red,
				TEXT("[Bridge] Assigned Ship НЕ назначен в деталях этого мостика на сцене!"));
		}
		return;
	}

	APawn* InstigatorPawn = Cast<APawn>(InteractingActor);
	if (!InstigatorPawn) return;

	AController* Controller = InstigatorPawn->GetController();
	if (!Controller) return;

	AssignedShip->EnterPilotMode(InstigatorPawn, Controller);
}

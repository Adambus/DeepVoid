#include "Ship/ShipModule_Weapon.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/DamageType.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "Net/UnrealNetwork.h"

AShipModule_Weapon::AShipModule_Weapon()
{
	bReplicates = true;
	// Как и у AShip - без этого встроенный механизм ReplicatedMovement периодически
	// "перетирает" позицию/поворот обратно, конфликтуя и с attach-следованием за
	// кораблём, и с ручным SetActorRelativeRotation() из прицеливания.
	SetReplicateMovement(false);

	// Отдельный пустой корень - именно ЕГО крутит логика прицеливания (aim yaw).
	// Mesh - дочерний, его собственный Rotation настраивайте как обычный компонент,
	// прямо в Details - никакой прицел его не трогает, только TurretRoot.
	TurretRoot = CreateDefaultSubobject<USceneComponent>(TEXT("TurretRoot"));
	SetRootComponent(TurretRoot);

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	Mesh->SetupAttachment(TurretRoot);
	Mesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(RootComponent);
	SpringArm->TargetArmLength = 800.f;
	SpringArm->SetRelativeRotation(FRotator(-70.f, 0.f, 0.f));
	// Мировой поворот, а не относительно актора - камера всегда смотрит "сверху вниз" в мировых
	// координатах, даже если сам актор турели случайно перекошен по Roll/Pitch на сцене
	// (например, после Attach к кораблю). Раньше камера наследовала этот перекос напрямую.
	SpringArm->SetUsingAbsoluteRotation(true);
	SpringArm->bDoCollisionTest = false; // тот же урок, что и с камерой персонажа/корабля

	TurretCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("TurretCamera"));
	TurretCamera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);
	TurretCamera->bUsePawnControlRotation = false;

	AutoPossessPlayer = EAutoReceiveInput::Disabled; // возможен только через явный Possess по F
	AutoPossessAI = EAutoPossessAI::Disabled; // иначе движок сам сажает сюда AI-контроллера при старте -
	                                            // из-за этого Controller был не пустым, и старая проверка
	                                            // "Controller == nullptr" молча блокировала интеракт
}

void AShipModule_Weapon::BeginPlay()
{
	Super::BeginPlay();

	// Однозначно проверяем, реально ли этот актор прикреплён к чему-либо на старте игры -
	// а не гадаем. Если тут NONE - значит attach физически не сохранился на этом экземпляре,
	// и дело не в коде вращения/движения вообще, а в расстановке на сцене.
	if (GEngine)
	{
		AActor* Parent = GetAttachParentActor();
		GEngine->AddOnScreenDebugMessage(-1, 15.f, Parent ? FColor::Green : FColor::Red,
			FString::Printf(TEXT("[Weapon] BeginPlay: AttachParentActor = %s"),
				Parent ? *Parent->GetName() : TEXT("NONE - НЕ ПРИКРЕПЛЕНО!")));
	}
}

void AShipModule_Weapon::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(AShipModule_Weapon, CurrentYawOffset);
	DOREPLIFETIME(AShipModule_Weapon, bIsOccupiedByPlayer);
	DOREPLIFETIME(AShipModule_Weapon, OperatorOriginalPawn);
}

void AShipModule_Weapon::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	if (UEnhancedInputComponent* EIC = Cast<UEnhancedInputComponent>(PlayerInputComponent))
	{
		if (RotateAction)
		{
			EIC->BindAction(RotateAction, ETriggerEvent::Triggered, this, &AShipModule_Weapon::Input_Rotate);
		}
		else if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 8.f, FColor::Red, TEXT("[Weapon] Rotate Action НЕ назначен в BP_ShipModule_Weapon!"));
		}

		if (FireAction)
		{
			EIC->BindAction(FireAction, ETriggerEvent::Started, this, &AShipModule_Weapon::Input_Fire);
		}
		else if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 8.f, FColor::Red, TEXT("[Weapon] Fire Action НЕ назначен в BP_ShipModule_Weapon!"));
		}

		if (ExitTurretAction)
		{
			EIC->BindAction(ExitTurretAction, ETriggerEvent::Started, this, &AShipModule_Weapon::Input_ExitTurret);
		}
		else if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 8.f, FColor::Red, TEXT("[Weapon] Exit Turret Action НЕ назначен в BP_ShipModule_Weapon!"));
		}
	}
}

void AShipModule_Weapon::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	if (APlayerController* PC = Cast<APlayerController>(NewController))
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem =
			ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer()))
		{
			if (TurretMappingContext)
			{
				Subsystem->AddMappingContext(TurretMappingContext, 10);
				if (GEngine)
				{
					GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, TEXT("[Weapon] Mapping Context добавлен"));
				}
			}
			else if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 8.f, FColor::Red,
					TEXT("[Weapon] Turret Mapping Context НЕ назначен в BP_ShipModule_Weapon!"));
			}
		}

		// Без этого дельты мыши приходят только пока зажата кнопка мыши (стандартная
		// настройка захвата курсора Unreal для click-to-move персонажей). Постоянный
		// захват даёт непрерывные дельты, не завися от того, зажата ли какая-то кнопка.
		if (PC->IsLocalController())
		{
			PC->SetShowMouseCursor(false);
			PC->SetInputMode(FInputModeGameOnly());
		}
	}
}

void AShipModule_Weapon::UnPossessed()
{
	if (APlayerController* PC = Cast<APlayerController>(GetController()))
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem =
			ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer()))
		{
			if (TurretMappingContext)
			{
				Subsystem->RemoveMappingContext(TurretMappingContext);
			}
		}

		// Возвращаем обычный режим курсора (видимый, не захваченный) - как обычно у
		// персонажа в Top-Down шаблоне. Если ваш персонаж использует другой режим ввода,
		// поправьте здесь под него.
		if (PC->IsLocalController())
		{
			PC->SetShowMouseCursor(true);

			// Явно DoNotLock - иначе стандартный FInputModeGameAndUI() всё равно частично
			// блокирует курсор при клике, и персонаж с прицеливанием по позиции мыши
			// (DeprojectMousePositionToWorld) начинает вести себя так же криво, как
			// раньше вело себя оружие - "работает только пока зажата кнопка".
			FInputModeGameAndUI InputMode;
			InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			InputMode.SetHideCursorDuringCapture(false);
			PC->SetInputMode(InputMode);
		}
	}

	Super::UnPossessed();
}

void AShipModule_Weapon::Input_Rotate(const FInputActionValue& Value)
{
	// Сырая дельта движения мыши за кадр (Axis2D от "Mouse XY 2D-Axis" в IMC).
	// Работает независимо от того, виден курсор или захвачен игрой - в отличие от
	// прошлой версии через мировые координаты, тут вообще не важно, где физически мышь.
	const float MouseDeltaX = Value.Get<FVector2D>().X;

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(5, 0.f, FColor::Cyan,
			FString::Printf(TEXT("[Weapon] Input_Rotate: DeltaX=%.2f"), MouseDeltaX));
	}

	ServerRotate(MouseDeltaX);
}

void AShipModule_Weapon::Input_Fire(const FInputActionValue& Value)
{
	ServerFire();
}

void AShipModule_Weapon::Input_ExitTurret(const FInputActionValue& Value)
{
	ServerExitTurret();
}

void AShipModule_Weapon::ServerRotate_Implementation(float MouseDeltaX)
{
	CurrentYawOffset = FMath::Clamp(CurrentYawOffset + MouseDeltaX * MouseSensitivity, -MaxTraverseDegrees, MaxTraverseDegrees);
	SetActorRelativeRotation(FRotator(0.f, CurrentYawOffset, 0.f));
	OnRep_CurrentYawOffset();

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(6, 0.f, FColor::Yellow,
			FString::Printf(TEXT("[Weapon] ServerRotate: CurrentYawOffset=%.1f"), CurrentYawOffset));
	}
}

void AShipModule_Weapon::ServerFire_Implementation()
{
	Fire();
}

void AShipModule_Weapon::ServerExitTurret_Implementation()
{
	ExitTurret();
}

void AShipModule_Weapon::Fire()
{
	if (!HasAuthority() || !bCanFire) return;

	bCanFire = false;
	GetWorld()->GetTimerManager().SetTimer(FireCooldownHandle, this, &AShipModule_Weapon::ResetFireCooldown, FireRate, false);

	const FVector Start = Mesh->GetComponentLocation();
	const FVector End = Start + GetActorForwardVector() * Range;

	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this);
	if (GetAttachParentActor()) Params.AddIgnoredActor(GetAttachParentActor());

	FHitResult Hit;
	const bool bHit = GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_GameTraceChannel1, Params);

	if (bHit && Hit.GetActor())
	{
		UGameplayStatics::ApplyPointDamage(
			Hit.GetActor(), Damage, GetActorForwardVector(),
			Hit, GetInstigatorController(), this, UDamageType::StaticClass());
	}
}

void AShipModule_Weapon::OnRep_CurrentYawOffset()
{
	SetActorRelativeRotation(FRotator(0.f, CurrentYawOffset, 0.f));
}

void AShipModule_Weapon::EnterTurret(APawn* CharacterToStore, AController* InstigatingController)
{
	if (!HasAuthority() || !InstigatingController) return;

	OperatorOriginalPawn = CharacterToStore;
	bIsOccupiedByPlayer = true;
	InstigatingController->Possess(this);
}

void AShipModule_Weapon::ExitTurret()
{
	if (!HasAuthority()) return;

	AController* OperatorController = GetController();
	if (OperatorController && OperatorOriginalPawn)
	{
		OperatorController->Possess(OperatorOriginalPawn);

		// Та же причина, что и у корабля - персонаж стоял непосейженным, пока его,
		// возможно, тащил корабль (CarryPassengers), а CharacterMovementComponent
		// параллельно жил своей жизнью. Сбрасываем накопленное состояние.
		if (ACharacter* Character = Cast<ACharacter>(OperatorOriginalPawn))
		{
			if (UCharacterMovementComponent* CMC = Character->GetCharacterMovement())
			{
				CMC->StopMovementImmediately();
			}
		}

		OperatorOriginalPawn = nullptr;
	}

	bIsOccupiedByPlayer = false;
}

FText AShipModule_Weapon::GetInteractionPrompt_Implementation() const
{
	return NSLOCTEXT("DeepVoid", "WeaponSeat", "Занять турель");
}

bool AShipModule_Weapon::CanInteract_Implementation(AActor* InteractingActor) const
{
	return !bIsOccupiedByPlayer;
}

void AShipModule_Weapon::OnInteract_Implementation(AActor* InteractingActor)
{
	APawn* InstigatorPawn = Cast<APawn>(InteractingActor);
	if (!InstigatorPawn)
	{
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("[Weapon] OnInteract: InteractingActor не Pawn"));
		return;
	}

	AController* InstigatingController = InstigatorPawn->GetController();
	if (!InstigatingController)
	{
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("[Weapon] OnInteract: у пешки нет контроллера"));
		return;
	}

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, TEXT("[Weapon] OnInteract: вызываю EnterTurret"));
	}

	EnterTurret(InstigatorPawn, InstigatingController);
}

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interaction/InteractableInterface.h"
#include "ShipModule_Docking.generated.h"

class UStaticMeshComponent;

UENUM(BlueprintType)
enum class ERampRotationAxis : uint8
{
	Pitch, // вокруг локальной оси Y - "классический" разводной мост
	Roll,  // вокруг локальной оси X
	Yaw    // вокруг локальной оси Z - как дверь
};

/**
 * Стыковочная дверь. F открывает/закрывает (просто поворот двери-меша на 90 градусов
 * с плавной интерполяцией в Tick). MVP-версия без проверки реальной стыковки корабля -
 * просто интерактивная дверь, логику "можно ли открыть" добавим позже.
 */
UCLASS()
class DEEPVOID_API AShipModule_Docking : public AActor, public IInteractableInterface
{
	GENERATED_BODY()

public:
	AShipModule_Docking();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Docking")
	TObjectPtr<UStaticMeshComponent> FrameMesh; // неподвижная рама

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Docking")
	TObjectPtr<UStaticMeshComponent> DoorMesh; // подвижная створка

	UPROPERTY(EditDefaultsOnly, Category = "Docking")
	float OpenAnglePitch = 90.f;

	// Если рампа заваливается не в ту сторону - просто переключите эту ось в деталях
	// компонента, пересобирать код не нужно.
	UPROPERTY(EditDefaultsOnly, Category = "Docking")
	ERampRotationAxis RotationAxis = ERampRotationAxis::Pitch;

	// Если после выбора правильной оси направление всё равно зеркальное - включите это.
	UPROPERTY(EditDefaultsOnly, Category = "Docking")
	bool bInvertDirection = false;

	UPROPERTY(EditDefaultsOnly, Category = "Docking")
	float OpenSpeedDegPerSec = 90.f;

	UPROPERTY(ReplicatedUsing = OnRep_IsOpen, BlueprintReadOnly, Category = "Docking")
	bool bIsOpen = false;

	float CurrentRampPitch = 0.f;

	UFUNCTION()
	void OnRep_IsOpen();

public:
	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const override;

	virtual FText GetInteractionPrompt_Implementation() const override;
	virtual bool CanInteract_Implementation(AActor* InteractingActor) const override;
	virtual void OnInteract_Implementation(AActor* InteractingActor) override;
};

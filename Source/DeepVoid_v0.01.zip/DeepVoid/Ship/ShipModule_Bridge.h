#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interaction/InteractableInterface.h"
#include "ShipModule_Bridge.generated.h"

class AShip;

/**
 * Мостик - простой актор-триггер (можно тоже сделать кубом визуально). Стоит рядом
 * с кораблём или внутри него. F рядом с ним пересаживает игрока на AssignedShip.
 * Повторный F/Esc для выхода обрабатывается уже самим кораблём (см. AShip::ExitPilotMode) -
 * этот класс отвечает только за "посадку", не за "высадку".
 */
UCLASS()
class DEEPVOID_API AShipModule_Bridge : public AActor, public IInteractableInterface
{
	GENERATED_BODY()

public:
	AShipModule_Bridge();

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Bridge")
	TObjectPtr<UStaticMeshComponent> Mesh;

	// Назначьте в деталях экземпляра на сцене - какой корабль пилотировать с этого мостика.
	UPROPERTY(EditInstanceOnly, Category = "Bridge")
	TObjectPtr<AShip> AssignedShip;

public:
	virtual FText GetInteractionPrompt_Implementation() const override;
	virtual bool CanInteract_Implementation(AActor* InteractingActor) const override;
	virtual void OnInteract_Implementation(AActor* InteractingActor) override;
};

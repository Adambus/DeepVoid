#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ShipBlockBase.generated.h"

class AShip;
class UStaticMeshComponent;

/**
 * Структурный блок корпуса - "кирпичик", из которых физически состоит корабль.
 * Один блок = ровно одна клетка сетки (в отличие от модулей у структурных блоков
 * нет footprint - неправильная форма корпуса достигается тем, какие клетки вообще
 * заполнены, а не формой отдельного блока - осознанное упрощение для соло-разработки).
 *
 * Abstract - конкретные визуальные варианты (обычная стена, скошенный угол и т.д.)
 * делайте Blueprint-подклассами.
 */
UCLASS(Abstract)
class DEEPVOID_API AShipBlockBase : public AActor
{
	GENERATED_BODY()

public:
	AShipBlockBase();

protected:
	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Block")
	TObjectPtr<USceneComponent> Root;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Block")
	TObjectPtr<UStaticMeshComponent> Mesh;

	UPROPERTY(EditDefaultsOnly, Category = "Block")
	float MaxHealth = 100.f;

	UPROPERTY(ReplicatedUsing = OnRep_Health, BlueprintReadOnly, Category = "Block")
	float Health = 100.f;

	UFUNCTION()
	void OnRep_Health();

	// true для "ядра" корабля - именно от таких клеток UShipGridComponent считает
	// связность (flood-fill/BFS). На сцене/у стартового корабля должен быть как
	// минимум один блок с bIsCore = true (обычно - клетка под мостиком), иначе
	// связность считать не от чего и отвал отсутствующих блоков не сработает.
	UPROPERTY(EditDefaultsOnly, Category = "Block")
	bool bIsCore = false;

public:
	UPROPERTY(BlueprintReadOnly, Category = "Block")
	TObjectPtr<AShip> OwningShip;

	UPROPERTY(BlueprintReadOnly, Category = "Block")
	FIntPoint GridCell = FIntPoint::ZeroValue;

	bool IsCore() const { return bIsCore; }
	float GetHealthPercent() const { return MaxHealth > 0.f ? Health / MaxHealth : 0.f; }

	// Сервер вызывает сразу после установки блока в сетку (UShipGridComponent::PlaceBlock).
	void InitializeBlock(AShip* InOwningShip, FIntPoint InCell);

	// Возвращает true, если блок уничтожен (Health <= 0) - вызывающий код
	// (например, боевая система) должен после этого вызвать
	// UShipGridComponent::RemoveBlock + RecalculateConnectivity.
	UFUNCTION(BlueprintCallable, Category = "Block")
	bool ApplyDamage(float DamageAmount);
};
